from tkinter import messagebox

def ShowMessage(title, message):
    messagebox.showinfo(title, message)