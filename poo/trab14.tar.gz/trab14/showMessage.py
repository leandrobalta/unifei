from tkinter import messagebox

def ShowMessage(msgHeader, msgBody):
    messagebox.showinfo(msgHeader, msgBody)
