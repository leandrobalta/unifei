#include <stdio.h>
#include <unistd.h>

int main(void)
{
    printf("\nPid do arquivo: %d\n", getpid());
    return 0;
}
