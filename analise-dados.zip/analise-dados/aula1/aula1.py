import seaborn as sns
import matplotlib.pyplot as plt

df = sns.sns.load_data